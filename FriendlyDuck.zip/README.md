# Friendly Duck 🐤

This mod makes the duck in R.E.P.O. friendly! No more surprise attacks — just cute jumps when you grab it.

## Installation
Use Thunderstore Mod Manager, or install manually by placing the DLL into your BepInEx `plugins` folder.

## Author
Made by @purplehaxttv
